-- Query 1: Monthly Sales Performance with Previous Month Comparison
-- Business Question: How are monthly sales performing compared to previous months?
-- This query analyzes month-to-month sales performance with growth metrics

SELECT 
    -- Extract time dimensions for analysis
    dd.year,
    dd.month,
    -- Calculate total sales and profit metrics
    SUM(fs.sales) AS monthly_sales,
    SUM(fs.profit) AS monthly_profit,
    -- Use LAG to get previous month's sales for comparison
    LAG(SUM(fs.sales), 1) OVER (ORDER BY dd.year, dd.month) AS prev_month_sales,
    -- Calculate month-over-month growth as percentage
    CASE 
        WHEN LAG(SUM(fs.sales), 1) OVER (ORDER BY dd.year, dd.month) IS NULL THEN NULL
        WHEN LAG(SUM(fs.sales), 1) OVER (ORDER BY dd.year, dd.month) = 0 THEN NULL
        ELSE ROUND(((SUM(fs.sales) - LAG(SUM(fs.sales), 1) OVER (ORDER BY dd.year, dd.month)) / 
               LAG(SUM(fs.sales), 1) OVER (ORDER BY dd.year, dd.month)) * 100, 2)
    END AS sales_growth_percent,
    -- Calculate profit margin
    ROUND((SUM(fs.profit) / SUM(fs.sales)) * 100, 2) AS profit_margin_percent
FROM 
    fact_sales fs
JOIN 
    dim_date dd ON fs.date_key = dd.date_key
-- Focus on 2019-2020 data
WHERE 
    dd.year IN (2019, 2020)
GROUP BY 
    dd.year, dd.month
ORDER BY 
    dd.year, dd.month;

-- This query provides monthly sales trends with month-over-month growth percentage,
-- allowing business leaders to identify seasonal patterns and performance changes.
-- The LAG function enables direct comparison with previous periods.