-- Query 3: Customer Segment Value Analysis
-- Business Question: Which customer segments are most valuable, and who are our top customers?
-- This query analyzes customer value across different segments with moving averages

SELECT
    -- Customer dimensions
    dc.segment,
    dc.customer_id,
    dc.customer_name,
    -- Total customer value
    SUM(fs.sales) AS total_sales,
    SUM(fs.profit) AS total_profit,
    COUNT(DISTINCT fs.order_id) AS order_count,
    -- Calculate average order value
    ROUND(SUM(fs.sales) / COUNT(DISTINCT fs.order_id), 2) AS avg_order_value,
    -- Calculate customer ranking within segment
    ROW_NUMBER() OVER (
        PARTITION BY dc.segment 
        ORDER BY SUM(fs.sales) DESC
    ) AS customer_rank_in_segment,
    -- Calculate moving average of sales (last 3 customers in ranking)
    -- This shows if higher-ranked customers have similar values
    ROUND(AVG(SUM(fs.sales)) OVER (
        PARTITION BY dc.segment 
        ORDER BY SUM(fs.sales) DESC
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 2) AS moving_avg_sales_3_customers
FROM 
    fact_sales fs
JOIN 
    dim_customer dc ON fs.customer_key = dc.customer_key
JOIN 
    dim_date dd ON fs.date_key = dd.date_key
WHERE 
    dd.year IN (2019, 2020)
GROUP BY 
    dc.segment, dc.customer_id, dc.customer_name
-- Only show top 10 customers per segment
HAVING 
    ROW_NUMBER() OVER (
        PARTITION BY dc.segment 
        ORDER BY SUM(fs.sales) DESC
    ) <= 10
ORDER BY 
    dc.segment, customer_rank_in_segment;

-- This query identifies the most valuable customers within each segment,
-- helping to target retention efforts and understand segment performance.
-- The moving average helps identify if there are significant drops in value
-- between consecutive customer rankings.