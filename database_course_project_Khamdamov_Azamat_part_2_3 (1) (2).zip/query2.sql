-- Query 2: Product Category Performance Analysis
-- Business Question: Which product categories drive the most revenue and how has their performance changed over time?
-- This query analyzes category performance with cumulative sales and ranking

SELECT 
    -- Time and category dimensions
    dd.year,
    dd.quarter,
    dc.category,
    dc.sub_category,
    -- Sales metrics
    SUM(fs.sales) AS quarterly_sales,
    SUM(fs.quantity) AS units_sold,
    -- Calculate cumulative sales by category within each year
    SUM(SUM(fs.sales)) OVER (
        PARTITION BY dd.year, dc.category 
        ORDER BY dd.quarter
        ROWS UNBOUNDED PRECEDING
    ) AS cumulative_yearly_sales,
    -- Rank categories by sales within each quarter
    RANK() OVER (
        PARTITION BY dd.year, dd.quarter 
        ORDER BY SUM(fs.sales) DESC
    ) AS sales_rank_in_quarter,
    -- Calculate percentage contribution to overall sales
    ROUND(
        (SUM(fs.sales) / SUM(SUM(fs.sales)) OVER (PARTITION BY dd.year, dd.quarter)) * 100, 
        2
    ) AS pct_of_quarterly_sales
FROM 
    fact_sales fs
JOIN 
    dim_date dd ON fs.date_key = dd.date_key
JOIN 
    dim_product dp ON fs.product_key = dp.product_key
JOIN 
    dim_category dc ON dp.category_key = dc.category_key
WHERE 
    dd.year IN (2019, 2020)
GROUP BY 
    dd.year, dd.quarter, dc.category, dc.sub_category
ORDER BY 
    dd.year, dd.quarter, sales_rank_in_quarter;

-- This analysis helps identify which product categories are performing best
-- and how their contribution changes over time. The cumulative sales show
-- how categories build revenue throughout the year, while the ranking shows
-- their relative importance each quarter.