-- Query 5: Regional Performance Analysis with YoY Comparison
-- Business Question: How are different regions performing and what is their year-over-year growth?
-- This query analyzes geographic performance trends with YoY comparisons

SELECT
    -- Geographic dimensions
    dl.region,
    dl.state,
    dd.year,
    -- Performance metrics
    SUM(fs.sales) AS annual_sales,
    SUM(fs.profit) AS annual_profit,
    COUNT(DISTINCT fs.order_id) AS order_count,
    -- Calculate year-over-year sales growth using LAG
    LAG(SUM(fs.sales), 1) OVER (
        PARTITION BY dl.region, dl.state 
        ORDER BY dd.year
    ) AS prev_year_sales,
    -- Calculate growth percentage
    CASE 
        WHEN LAG(SUM(fs.sales), 1) OVER (PARTITION BY dl.region, dl.state ORDER BY dd.year) IS NULL THEN NULL
        WHEN LAG(SUM(fs.sales), 1) OVER (PARTITION BY dl.region, dl.state ORDER BY dd.year) = 0 THEN NULL
        ELSE ROUND(
            ((SUM(fs.sales) - LAG(SUM(fs.sales), 1) OVER (PARTITION BY dl.region, dl.state ORDER BY dd.year)) / 
             LAG(SUM(fs.sales), 1) OVER (PARTITION BY dl.region, dl.state ORDER BY dd.year)) * 100, 
             2
        )
    END AS yoy_growth_pct,
    -- Rank states within regions by sales
    RANK() OVER (
        PARTITION BY dl.region, dd.year 
        ORDER BY SUM(fs.sales) DESC
    ) AS state_rank_in_region,
    -- Calculate region's contribution to total sales
    ROUND(
        (SUM(fs.sales) / SUM(SUM(fs.sales)) OVER (PARTITION BY dd.year)) * 100,
        2
    ) AS pct_of_total_sales
FROM 
    fact_sales fs
JOIN 
    dim_location dl ON fs.customer_key = fs.customer_key -- (Using dim_customer location relationship)
JOIN 
    dim_date dd ON fs.date_key = dd.date_key
WHERE 
    dd.year IN (2019, 2020)
GROUP BY 
    dl.region, dl.state, dd.year
ORDER BY 
    dl.region, state_rank_in_region, dd.year;

-- This analysis helps identify regional performance patterns and growth trends.
-- The year-over-year comparison highlights regions and states with changing performance,
-- while the ranking shows each state's importance within its region.
-- Understanding geographic performance helps in resource allocation and expansion planning.