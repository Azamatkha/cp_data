
-- dim_date
INSERT INTO dim_date (date_key, full_date, day, month, quarter, year)
SELECT DISTINCT 
    TO_CHAR(order_date, 'YYYYMMDD')::BIGINT,
    order_date,
    EXTRACT(DAY FROM order_date),
    TO_CHAR(order_date, 'Month'),
    EXTRACT(QUARTER FROM order_date),
    EXTRACT(YEAR FROM order_date)
FROM staging_orders;

-- dim_location
INSERT INTO dim_location (location_key, country, city_name, city_id, state, state_id, region, region_id)
SELECT DISTINCT 
    ROW_NUMBER() OVER() AS location_key,
    country,
    city,
    DENSE_RANK() OVER(PARTITION BY state ORDER BY city),
    state,
    DENSE_RANK() OVER(ORDER BY state),
    region,
    DENSE_RANK() OVER(ORDER BY region)
FROM staging_orders;

-- dim_customer
INSERT INTO dim_customer (customer_key, customer_id, customer_name, segment, location_key)
SELECT DISTINCT
    ROW_NUMBER() OVER() AS customer_key,
    customer_id,
    customer_name,
    segment,
    dl.location_key
FROM staging_orders s
JOIN dim_location dl ON s.city = dl.city_name AND s.state = dl.state AND s.country = dl.country;

-- dim_product
INSERT INTO dim_product (product_key, product_id, product_name, category_id, category_name, sub_category_id, sub_category_name)
SELECT DISTINCT
    ROW_NUMBER() OVER() AS product_key,
    product_id,
    product_name,
    DENSE_RANK() OVER(ORDER BY category),
    category,
    DENSE_RANK() OVER(ORDER BY sub_category),
    sub_category
FROM staging_orders;

-- dim_shipping
INSERT INTO dim_shipping (ship_key, ship_mode_id, ship_mode_name, days_to_ship)
SELECT DISTINCT
    ROW_NUMBER() OVER() AS ship_key,
    ship_date,
    ship_mode,
    (ship_date - order_date)
FROM staging_orders;

-- fact_sales
INSERT INTO fact_sales (order_id, date_key, customer_key, location_key, product_key, ship_key, sales, quantity, profit)
SELECT
    s.order_id,
    TO_CHAR(s.order_date, 'YYYYMMDD')::BIGINT,
    dc.customer_key,
    dc.location_key,
    dp.product_key,
    ds.ship_key,
    s.sales,
    s.quantity,
    s.profit
FROM staging_orders s
JOIN dim_customer dc ON s.customer_id = dc.customer_id
JOIN dim_product dp ON s.product_id = dp.product_id
JOIN dim_shipping ds ON s.ship_date = ds.ship_mode_id AND s.ship_mode = ds.ship_mode_name;
