
-- Create dim_date table
CREATE TABLE dim_date (
    date_key BIGINT PRIMARY KEY,
    full_date DATE NOT NULL,
    day BIGINT NOT NULL,
    month VARCHAR(20) NOT NULL,
    quarter BIGINT NOT NULL,
    year BIGINT NOT NULL
);

-- Create dim_location table
CREATE TABLE dim_location (
    location_key BIGINT PRIMARY KEY,
    country VARCHAR(50) NOT NULL,
    city_name VARCHAR(50) NOT NULL,
    city_id BIGINT NOT NULL,
    state VARCHAR(50) NOT NULL,
    state_id BIGINT NOT NULL,
    region VARCHAR(50) NOT NULL,
    region_id BIGINT NOT NULL
);

-- Create dim_customer table
CREATE TABLE dim_customer (
    customer_key BIGINT PRIMARY KEY,
    customer_id VARCHAR(50) NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    segment VARCHAR(50) NOT NULL,
    location_key BIGINT NOT NULL,
    FOREIGN KEY (location_key) REFERENCES dim_location(location_key)
);

-- Create dim_product table
CREATE TABLE dim_product (
    product_key BIGINT PRIMARY KEY,
    product_id VARCHAR(50) NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    category_id BIGINT NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    sub_category_id BIGINT NOT NULL,
    sub_category_name VARCHAR(100) NOT NULL
);

-- Create dim_shipping table
CREATE TABLE dim_shipping (
    ship_key BIGINT PRIMARY KEY,
    ship_mode_id DATE NOT NULL,
    ship_mode_name VARCHAR(50) NOT NULL,
    days_to_ship BIGINT NOT NULL
);

-- Create fact_sales table
CREATE TABLE fact_sales (
    order_id VARCHAR(50) NOT NULL,
    date_key BIGINT NOT NULL,
    customer_key BIGINT NOT NULL,
    location_key BIGINT NOT NULL,
    product_key BIGINT NOT NULL,
    ship_key BIGINT NOT NULL,
    sales DECIMAL(10,2) NOT NULL,
    quantity BIGINT NOT NULL,
    profit DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (order_id, date_key, customer_key, product_key, ship_key),
    FOREIGN KEY (date_key) REFERENCES dim_date(date_key),
    FOREIGN KEY (customer_key) REFERENCES dim_customer(customer_key),
    FOREIGN KEY (location_key) REFERENCES dim_location(location_key),
    FOREIGN KEY (product_key) REFERENCES dim_product(product_key),
    FOREIGN KEY (ship_key) REFERENCES dim_shipping(ship_key)
);
